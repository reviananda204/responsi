import 'package:flutter/material.dart';
import 'edit_profile.dart'; 

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profil'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundImage: AssetImage('assets/profile_picture.png'),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Revi Ananda',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 5),
                  Text(
                    'Universitas Teknologi Yogyakarta',
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                ],
              ),
            ),
            SizedBox(height: 30),

            ListView(
              shrinkWrap: true,
              children: [
                _buildListItem('Kelola Akun', Icons.account_circle, context),
                _buildListItem('Notifikasi', Icons.notifications, context),
                _buildListItem('Privacy Policy', Icons.security, context),
                _buildListItem('Terms of Service', Icons.description, context),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildListItem(String title, IconData icon, BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(title, style: TextStyle(fontSize: 18)),
      trailing: Icon(Icons.arrow_forward_ios, size: 16),
      leading: Icon(icon, size: 24, color: Colors.blue),
      onTap: () {
        if (title == 'Kelola Akun') {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => EditProfilePage()), 
          );
        }
      },
    );
  }
}
